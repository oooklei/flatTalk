import { includesTerm } from '../scoring-engine.js';

const serviceTopicTerms = [
  '养老', '护工', '护理', '养老院', '机构', '上门', '助浴', '陪诊', '助餐', '送餐',
  '清洁', '康复', '认知症', '护理员', '家政', '照护', '服务', '康养',
];
const serviceIntentTerms = [
  '找', '推荐', '预约', '安排', '下单', '订', '匹配', '查询', '查看', '申请', '需要', '我要', '帮我',
  '有哪些', '入住', '想', '希望', '了解', '咨询', '知道', '什么', '怎么', '能不能', '可以',
  '目录', '全部', '订单', '我的订单', '服务订单',
];
const serviceTypeTerms = [
  '上门护理', '助浴', '陪诊就医', '陪诊', '康复训练', '助餐', '居家清洁', '养老机构', '机构养老', '养老床位', '认知症照护', '护理站',
  '订单', '服务订单', '目录',
];
const elderConstraintTerms = [
  '老人', '长者', '老年人', '爷爷', '奶奶', '爸妈', '父母', '家属', '失能', '半失能', '独居', '高龄',
];

export const findServiceRuleSet = {
  scene_key: 'find_service',
  default_intent: 'find_service_discover',
  threshold: 8,
  template_candidates: ['service_recommend', 'service_catalog', 'org_profile', 'worker_profile', 'order_preview', 'order_status', 'fallback'],
  required_data: ['fs_service_catalog', 'fs_org', 'fs_worker', 'fs_service_order'],
  required_knowledge: ['find_service'],
  actions_allowed: [
    'find_service.recommend',
    'find_service.catalog',
    'find_service.list_orgs',
    'find_service.book_org',
    'find_service.list_workers',
    'find_service.book_worker',
    'find_service.confirm_order',
    'find_service.detail_order',
  ],
  followup_policy: 'find_service.default',
  evidence_groups: [
    { group: 'service_topic', weight: 3, terms: serviceTopicTerms },
    { group: 'service_intent', weight: 3, terms: serviceIntentTerms },
    { group: 'service_type', weight: 2.5, terms: serviceTypeTerms },
    { group: 'elder_constraint', weight: 1.5, terms: elderConstraintTerms },
  ],
  role_boost: {
    roles: ['elder', 'elder_family', 'family', 'system_admin'],
    weight: 1,
  },
  context_boost: {
    previous_scene: 'find_service',
    weight: 5,
    terms: ['这个', '这位', '预约', '下单', '接单', '安排', '继续', '再推荐', '换一个'],
  },
  conflicts: [
    { group: 'meal_plan', penalty: 4, terms: ['膳食', '饮食', '早餐', '午餐', '晚餐', '菜谱', '控糖餐', '低盐'] },
    { group: 'travel_route', penalty: 4, terms: ['旅居', '旅游', '路线', '线路', '行程', '目的地', '广西', '防城港'] },
    { group: 'dispatch_manage', penalty: 4, terms: ['派单', '工单', '调度', '接单', '拒单', '改派'] },
    { group: 'acute_health_risk', penalty: 3.5, terms: ['胸痛', '昏迷', '呼吸困难', '中风', '急救', '120'] },
  ],
  infer_intent(input) {
    if (has(input, ['养老院', '机构', '护理站', '入住'])) return 'find_service_org';
    if (has(input, ['预约', '下单', '建单', '安排', '我要订', '订'])) return 'find_service_order';
    if (has(input, ['订单', '我的订单', '服务订单', '查看订单'])) return 'find_service_order_view';
    if (has(input, ['护工', '护理员', '人员', '上门'])) return 'find_service_worker';
    if (has(input, ['目录', '全部', '分类', '有哪些'])) return 'find_service_catalog';
    return 'find_service_discover';
  },
};

export function identifyFindServiceScene(input) {
  const text = extractText(input);
  for (const g of findServiceRuleSet.evidence_groups) {
    const hit = g.terms.find((t) => includesTerm(text, t));
    if (hit) {
      return {
        scene_key: 'find_service',
        intent: findServiceRuleSet.default_intent,
        scene_name: '找养老服务',
        confidence: 0.9,
        skill_key: 'find_service',
        matched_keyword: hit,
      };
    }
  }
  return null;
}

function has(input, terms) {
  const text = typeof input === 'string'
    ? input
    : [input?.text, input?.utterance, input?.message, input?.query].filter(Boolean).join(' ');
  return terms.some((term) => includesTerm(text, term));
}

function extractText(input) {
  if (typeof input === 'string') return input;
  return [input?.text, input?.utterance, input?.message, input?.query].filter(Boolean).join(' ');
}
